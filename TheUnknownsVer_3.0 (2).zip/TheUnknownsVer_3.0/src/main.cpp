// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// Intake               motor         18              
// FlywheelMainMotor    motor         1               
// Indexer3498348923    motor         8               
// LF                   motor         12              
// LR                   motor         13              
// RF                   motor         14              
// RR                   motor         15              
// LeftEncoderY         encoder       E, F            
// RightEncoderY        encoder       C, D            
// Inertial1            inertial      11              
// Pnematics            digital_out   G               
// EncoderX             encoder       A, B            
// ColorSensorRight     optical       6               
// ---- END VEXCODE CONFIGURED DEVICES ----
#include "vex.h" // Includes the vex libray
#include"NameSpaceGlobal.h" // Includes My Ligbrary
using namespace vex; // Exports All of the functions and types in namespace "vex"
using namespace DisplayControls; // Exports All of the functions and types in namespace "DisplayControls"
using namespace UserControl;// Exports All of the functions and types in namespace "UserControl"
using namespace Odometry;
using namespace Auton;

competition Competition; // Delcares the Competion
int main() { // The Main Function
    Inertial1.calibrate();
  while(Inertial1.isCalibrating()){
    wait(15, msec);
  }
 Odometry::Set::setInit();
  thread thread1(Odometry::Orientation::OrientationInit);
  thread thread2(Odometry::odomInit);
  ColorSensor.setLight(ledState::on);
    ColorSensorRight.setLight(ledState::on);
  Competition.drivercontrol(UserControl::usercontrol); // Delcares User Control
  Competition.autonomous(Auton::autonomous);

 DisplayControls::  DisplayMain(); // Displays Things on the screen
}
/*
Why I did this: 
I decided to reorganize my code because of a long main file and to better organize it.
*/
