#include <cmath>
namespace Odometry{
  inline namespace cmath2{
double absd(double a ){
  if(a<0){
    a = a*-1;
  }
  return a;
}
/// Turn Pd
double keepoutofrange(double double1,double double2){
  double product;
  bool isnegative = double1 < 0;
  double m = 1;
  if(isnegative) m = -1;
  if(absd(double1) < absd(double2)){
    product = absd(double2) * m;
  }
  else{
    product = double1;
  }
  return product;
}
double keeplessthan(double double1,double double2,double double3){
double product;
if (double2 < double1){
  product = double2;
  
}
else{
  if(double3 > double1){
    product = double3;
  }
  else{
  product = double1;
  }
}


  return product;

}
double conststrainAngle(double angle){
  angle = fmod(angle + 180,360);
  if(angle<180){
    angle+=360;
  }
  return angle - 180;
}
double getDesiredHeadingforRotate(double x1,double y1,double x2, double y2 ){
  // NOTE: returns the desired rotation value needs to be converted into rotation later
double deltaX = x2-x1;
double deltaY = y2-y1;
if(deltaX ==0){
  deltaX = 0.1;
}
if (deltaY == 0){
  deltaY = 0.1;
}

double theta = (std::atan(deltaX/deltaY) * 180) / 3.14159265;

double desiredRotation = 0;
if(x2>x1 && y2>y1){
  desiredRotation = theta;
}
if(x2<x1&& y2<y1){
  desiredRotation = theta + 180;
}if(y2 == y1){
  if (deltaX < 0){
desiredRotation = 270;
  }
  else{

  
  desiredRotation = 90;
  }
}
if(x2>x1 && y2<y1){desiredRotation = 180+theta;}if(x2<x1 && y2>y1){desiredRotation = theta;}desiredRotation = fmod(desiredRotation,360);
while(desiredRotation<0){
  desiredRotation = 360+desiredRotation;
}
if(x2 == x1){
  desiredRotation = -1;
}
return (desiredRotation);
}


  }}