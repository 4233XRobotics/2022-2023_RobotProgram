#include "robot-config.h"
#include "vex.h"

using namespace vex;
using namespace std;
namespace ButtonControls{
  inline namespace AutonControls{
     int selectedauton = 0; 
  const char* AutonStrings[6] = {"Left Spin","Left WinPoint","Right WinPoint","Skills","No wait endgame ","Test Odom"};
  int numberofautons = 6;

    bool Cooldown54 = false;
     void SwitchAuton(){
         if(Cooldown54 == false){
           if((selectedauton +1) == numberofautons){
             selectedauton = 0;
             Cooldown54 = true;
             task::sleep(300);
             Cooldown54 = false;
           }
           else{
             selectedauton = selectedauton + 1;
             Cooldown54 = true;
             task::sleep(300);
             Cooldown54 = false;
           }
         }
     }
  



  }
}