#include "AutonFunctions.h"
#include "robot-config.h"
using namespace ButtonControls::AutonControls;
namespace ButtonControls{
   inline namespace EndgameControls{
     bool dijoasdijpiucaosHkjlfdsjkfjkldsjfsdhfskjfsjkfkjd = false;
    void Release() {
     Pnematics.set(true); 
    }
    void Retract(){
      Pnematics.set(false);
    }
    void endgame(){
      if (AutonControls::selectedauton == 3){
       if(Brain.Timer.time(timeUnits::sec) >= 49 && !dijoasdijpiucaosHkjlfdsjkfjkldsjfsdhfskjfsjkfkjd){
          Pnematics.set(true);
        dijoasdijpiucaosHkjlfdsjkfjkldsjfsdhfskjfsjkfkjd = true;
          task::sleep(1000);
              Pnematics.set(false);
              dijoasdijpiucaosHkjlfdsjkfjkldsjfsdhfskjfsjkfkjd = false;
       } 
      }
      else{
          if (AutonControls::selectedauton == 4) {
              if (!dijoasdijpiucaosHkjlfdsjkfjkldsjfsdhfskjfsjkfkjd) {
                  Pnematics.set(true);
                  dijoasdijpiucaosHkjlfdsjkfjkldsjfsdhfskjfsjkfkjd = true;
                  task::sleep(1000);
                  Pnematics.set(false);
                  dijoasdijpiucaosHkjlfdsjkfjkldsjfsdhfskjfsjkfkjd = false;
              }
          }
          else {
              if (Brain.Timer.time(timeUnits::sec) >= 109 && !dijoasdijpiucaosHkjlfdsjkfjkldsjfsdhfskjfsjkfkjd) {
                  Pnematics.set(true);
                  dijoasdijpiucaosHkjlfdsjkfjkldsjfsdhfskjfsjkfkjd = true;
                  task::sleep(1000);
                  Pnematics.set(false);
                  dijoasdijpiucaosHkjlfdsjkfjkldsjfsdhfskjfsjkfkjd = false;
              }
          }
      }
    }
   }
}