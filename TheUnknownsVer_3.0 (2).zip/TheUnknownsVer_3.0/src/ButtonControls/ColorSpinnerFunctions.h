#include "robot-config.h"
namespace ButtonControls{
 inline namespace ColorSpinnerFunctions{
   bool IsBlue = false;
   bool Cooldown4 = false;
   void ChangeColor(){
     if (Cooldown4 == false){
     IsBlue  = !IsBlue;
       Cooldown4 = true;
     task::sleep(300);
     Cooldown4 = false;
   }
   }
   int id = 0;

   void SpinUntilBlue(bool CompetitionStart = true// Defining the speed ,changed this many times throughout testing
){ // Define Fuction
  bool Con = true; // Defining The Continue While Loop Varible;
  ColorSpinner2.spin(forward,60,percentUnits::pct); // Start Spin;ning the wheel
  ColorSensor.setLight(ledState::on);
  ColorSensorRight.setLight(ledState::on);
double sus = 1;
if (CompetitionStart) {
    sus = 1;
    while (Con) {
        if (ColorSensor.color() == red|| ColorSensorRight.color() == red) {
            Con = false;
        }
        if (sus >= 66.66666666666667) {
            Con = false;
        }
        task::sleep(15);
        sus = sus + 1;
       
    }
}
sus = 1;
  Con = true;
  while (Con){ // Define the while loop

    if (((ColorSensor.color() == blue)|| ColorSensorRight.color() == blue)){ // Check if the color of the sensor is blue
    task::sleep(100);
   Con = false; // Stops the while loop
    ColorSpinner2.stop(); // Stops The motor
    }

  

  
 if (sus >= 150){  ColorSpinner2.stop();
    Con = false;
  }
  vex::task::sleep(20); // A Small Wait to save resoures 
  sus  = sus+1; 
  }
ColorSpinner2.stop();
}
    
void SpinUntilRed( bool CompetitionStart = true,bool SkillsBack = false
){  
bool Con = true; // Defining The Continue While Loop Varible
    ColorSpinner2.setStopping(hold);
ColorSpinner2.spin(forward,60,percentUnits::pct); // Start Spin;ning the wheel
double sus = 1;
if (CompetitionStart) {
    while (Con == true) {
        if ((ColorSensor.color() == blue) || ColorSensorRight.color() == blue) {
            Con = false;
        }
        if (sus >= 66.66666666666667) {
            Con = false;
        }
        task::sleep(15);
        sus = sus + 1;
    }
}

  Con = true;
  sus = 1;
  while (Con){ // Define the while loopdsadsadasdada


    if ((ColorSensor.color() == red|| ColorSensorRight.color() == red) ){ // Check if the color of the sensor is blue
      
        task::sleep(100);
      
   Controller1.rumble("___");
   Con = false; // Stops the while loop
    ColorSpinner2.stop(); // Stops The motor
    if(SkillsBack){
ColorSpinner2.setVelocity(60, percentUnits::pct);
   ColorSpinner2.spinFor(-.2,rotationUnits::rev);
    }
    
  }


  
    if (sus >= 150) {
        Con = false;
 }
  vex::task::sleep(20); // A Small Wait to save resoures 
  sus  = sus+1; 
  }

ColorSpinner2.stop();
}
void STOPSpinner(){
  ColorSpinner2.stop();
}
void ColorSpinnerMainFunction(){
  if (IsBlue){
    SpinUntilBlue();
  }else{
    SpinUntilRed();
  }
}
 }
}