#include "robot-config.h"
#include "odometry.h"
using namespace vex;
namespace ButtonControls{
  inline namespace ShooterFunctions{
    bool Shooting = false;
    double ShootingPower = 90;
bool Cooldown1 = false;
void  AddPower(){
 if((ShootingPower+ 10) >= 110 && !Cooldown1){
   
 }
 else{
  if(Cooldown1== false && Controller1.ButtonA.pressing() == false){
      if(ShootingPower == 75){
          ShootingPower = ShootingPower + 5;
          if (Shooting) {
              FlywheelMainMotor.spin(forward, ((12.5 * ShootingPower) * 0.01), voltageUnits::volt);
          }
          Cooldown1 = true;
          vex::task::sleep(300);
          Cooldown1 = false;
      }
      else {
          ShootingPower = ShootingPower + 10;
          if (Shooting) {
              FlywheelMainMotor.spin(forward, ((12.5 * ShootingPower) * 0.01), voltageUnits::volt);
          }
          Cooldown1 = true;
          vex::task::sleep(300);
          Cooldown1 = false;
      }
  }
 }
}
bool Cooldown2 = false;
void RemovePower(){
    if((ShootingPower - 5) <= 70 && !Cooldown2){

   
 }
 else{
  if(Cooldown2 == false){
      if (ShootingPower == 80) {
          ShootingPower = ShootingPower - 5;
          if (Shooting) {
              FlywheelMainMotor.spin(forward, ((12.5 * ShootingPower) * 0.01), voltageUnits::volt);
          }
          Cooldown2 = true;
          vex::task::sleep(300);
          Cooldown2 = false;
      }
      else {
          ShootingPower = ShootingPower - 10;
          if (Shooting) {
              FlywheelMainMotor.spin(forward, ((12.5 * ShootingPower) * 0.01), voltageUnits::volt);
          }
          Cooldown2 = true;
          vex::task::sleep(300);
          Cooldown2 = false;
      }
  }
 }
}
bool CoolingDownYourMom = false;
void Shoot(){
  if(!Shooting && !CoolingDownYourMom){
    CoolingDownYourMom = true;
   Shooting = true;
   FlywheelMainMotor.spin(forward,((12.5*ShootingPower)*0.01),voltageUnits::volt);
   // Now we are cool
   task::sleep(1000);
   CoolingDownYourMom = false;
  }
  else{
    if(!CoolingDownYourMom && !Controller1.ButtonL1.pressing()){
      CoolingDownYourMom = true;
      Indexer3498348923.setVelocity(180,velocityUnits::rpm);
      Indexer3498348923.spinFor(reverse, 1, rev);
      task::sleep(50);
      CoolingDownYourMom = false;
    }
  }
}
void STOPShoot(){
  if (Shooting){
    Shooting = false;
    FlywheelMainMotor.stop(coast);
  }
}
bool  CooldownHold = true;
bool Pressing = false;
bool RelesedOne = false;
bool ReleasedTwo = false;
void rl1(){
  RelesedOne = true;
}
void rl2(){
  ReleasedTwo = true;
}
void IndexerHold(){
  if( Pressing == false){
    Pressing = true;
      Indexer3498348923.setVelocity(180,velocityUnits::rpm);
      Indexer3498348923.spinFor(reverse, 3, rev);
   Pressing = false;
   CooldownHold = true;
   ReleasedTwo = false;
   RelesedOne = false;
  }
}

  }
}