#include "robot-config.h"
 using namespace vex;
 
 namespace ButtonControls{
   inline namespace IntakeFunctions{
     bool Cooldown1 = false;
     double SpinningPower = 85;
bool Spinning = false;
void StartIntake(){
  if(!Spinning && !Cooldown1){
    Spinning = true;
  Intake.spin(reverse,SpinningPower,percent);
  Cooldown1 = true;
  task::sleep(1000);
  Cooldown1 = false;
  }
  else{
    if(!Cooldown1){
    Intake.stop(coast);
    Spinning = false;
       Cooldown1 = true;
  task::sleep(1000);
  Cooldown1 = false;
    }
  }
}


bool Cooldown2 = false;
void addpower(){

  if(Cooldown2 == false){
      Intake.stop();
      task::sleep(100);
      Intake.spin(forward, SpinningPower, percent);
    Cooldown2 = true;
    task::sleep(300);
    Cooldown2 = false;
  }}

bool Cooldown3 = false;
void removepower(){
    if((SpinningPower - 10) <= -110 && !Cooldown3){

   
 }
 else{
  if(Cooldown3 == false){
    SpinningPower = SpinningPower-10;
      Cooldown3 = true;
    task::sleep(300);
    Cooldown3 = false;
  }
 }
}
bool CoolDownyumyum = false;
void FixDisk(){
  if(!CoolDownyumyum){
  CoolDownyumyum = true;
  Intake.spin(forward,SpinningPower,percent);
  task::sleep(750);
  Intake.spin(reverse,SpinningPower,percent);
    task::sleep(750);
    Intake.stop();
    CoolDownyumyum = false;
  }
}
   }
 }