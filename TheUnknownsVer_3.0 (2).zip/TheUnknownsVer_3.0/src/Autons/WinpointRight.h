#include "WinPointLeft.h"
#include "robot-config.h"
using namespace Auton::AutonFunctions;
using namespace ButtonControls;
namespace Auton{
  namespace Autons{
      void StopAt15() {
        
              Brain.Timer.reset();
              waitUntil(Brain.Timer.time(timeUnits::sec) >= 15);
               old_Turn(false, 2, 2, 0);
              ColorSpinner2.stop();
              Controller1.rumble("........");
          
      }
    void WinPointRight(){
      Brain.Timer.reset();
     thread uwu(IntakeFunctions::StartIntake);
     double PastShooterPower = ShootingPower;
     
       old_Drive(19,150);
      task::sleep(500);
      SpinningPower = 75;
       old_Turn(true,10);
task::sleep(1000);
       old_Drive(2, 150); 
      thread uwu2(IntakeFunctions::StartIntake);
      ShootingPower = 100;
      Shoot();
      task::sleep(1000);
      SpinningPower = -75;
      IntakeFunctions::StartIntake();
         Indexer3498348923.setVelocity(190,velocityUnits::rpm);
      Indexer3498348923.spinFor(reverse, 1, rev);
      task::sleep(750);   
         Indexer3498348923.spinFor(reverse, 1, rev);
      task::sleep(750);
               Indexer3498348923.spinFor(reverse, 1, rev);
      task::sleep(100);
      STOPShoot();
       old_Turn(false, 330, 50);
           old_Drive(25,150,reverse);
     


           old_Turn(true, 18);

          LF.spin(reverse, 40, percent);

          LR.spin(reverse, 40, percent);

          RF.spin(reverse, 40, percent);
          RR.spin(reverse, 40, percent);


          if (ButtonControls::IsBlue == true) {
              ButtonControls::SpinUntilBlue();
          }
          else {
              ButtonControls::SpinUntilRed();
          }
          ButtonControls::stopallmotors();
          ShootingPower = PastShooterPower;
          SpinningPower = 75;
          IntakeFunctions::StartIntake();

    // UWUds adadadada
    }
  }

}