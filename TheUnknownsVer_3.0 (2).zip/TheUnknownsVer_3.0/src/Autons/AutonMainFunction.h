
#include "Autons.h"
using namespace ButtonControls;
using namespace ButtonControls::AutonControls;
namespace Auton{
  void autonomous(){
    Brain.resetTimer();
    if(ButtonControls::AutonControls::selectedauton == 0){
     Auton::Autons::LeftSpin();
    }
    else{
      if(ButtonControls::AutonControls::selectedauton == 1){
        Auton::Autons::WinPointLeft();
      }
      else{
        if(ButtonControls::AutonControls::selectedauton == 2){
          Auton::Autons::WinPointRight();
        }
        else {
            if (ButtonControls::AutonControls::selectedauton == 3)
            {
                Auton::Autons::Skills();
            }
            else {
                if (ButtonControls::AutonControls::selectedauton == 5) {
                    Auton::Autons::TestOdom();
                }
            }
        }
      }
    }
  }
}