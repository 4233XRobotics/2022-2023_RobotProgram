#include "../Display.h"
#include <cmath>
using namespace ButtonControls;
using namespace vex;
using namespace Odometry;
namespace Auton{

  inline namespace AutonFunctions{
    
    void SetInPos(double cx, double cy,double orientation = 0){
    xPosGlobal  = xPosGlobal + (cx/1.04166666667);
    yPosGlobal = yPosGlobal + (cy/0.91466203237);
    OrientationStart +=orientation;
    } 
      void old_Drive(float distance, float velocity, directionType direction = fwd, brakeType bt = hold,bool UsesInchesSystem = true) {
          if (UsesInchesSystem) {
              distance = distance / 0.02181661564;
          }
          double PastPositionLeft = LeftEncoderY.position(degrees);
          double PastPositionRight = RightEncoderY.position(degrees);
          LF.spin(direction, velocity, velocityUnits::rpm);
          LR.spin(direction, velocity, velocityUnits::rpm);
          RF.spin(direction, velocity, velocityUnits::rpm);
          RR.spin(direction, velocity, velocityUnits::rpm);
          bool Continue = true;
          LeftEncoderY.setPosition(0, degrees);
          RightEncoderY.setPosition(0, degrees);
          
          while (Continue) {
              if (direction == fwd) {
                  if ((LeftEncoderY.position(degrees) > (distance)) && ((RightEncoderY.position(degrees)/* * -1 */) > (distance))) {
                      Continue = false;
                  }
              }
              else {
                  if ((LeftEncoderY.position(degrees) < (-distance)) &&
                      ((RightEncoderY.position(degrees) /* *-1*/) < (-distance))) {
                      Continue = false;
                  }
              }
              /*
              double m =((1-LeftEncoderY.position(degrees)/distance)+(1-RightEncoderY.position(degrees)/distance))/2;
              if (m<0.7){
                m = 0.7;
              }
                LF.spin(direction,velocity*m,velocityUnits::rpm);
      LR.spin(direction,velocity*((1-LeftEncoderY.position(degrees)/distance)+(1-RightEncoderY.position(degrees)/distance))/2,velocityUnits::rpm);
           RF.spin(direction,velocity*((1-LeftEncoderY.position(degrees)/distance)+(1-RightEncoderY.position(degrees)/distance))/2,velocityUnits::rpm);
            RR.spin(direction,velocity*((1-LeftEncoderY.position(degrees)/distance)+(1-RightEncoderY.position(degrees)/distance))/2,velocityUnits::rpm);

*/
          }
          ButtonControls::stopallmotors(bt);

      }
     void old_Turn(bool Right,double degreesofturn,double speedofturn = 67,double rangeoferror = 1){
        
  double multiplier = 1;
  
  if(Right == false){
    multiplier = -1;
  }
  if (degreesofturn <= 0){
    degreesofturn = degreesofturn *-1;
    multiplier = multiplier * -1;
  }

   speedofturn = multiplier*speedofturn;
  LF.spin(forward,speedofturn,percentUnits::pct);
LR.spin(fwd,speedofturn,percent);
RF.spin(reverse,speedofturn,percentUnits::pct);
RR.spin(reverse, speedofturn, percentUnits::pct); // adkdasldkjasdlakdkjsaldsklsakdjaldjasdjadjadjadjkadjawdjlkawdlkjawdlkadjkadjkaldADADDADADADA
double pastHeading = CalulatedHeadingDeg;


   double degminus5 = degreesofturn-rangeoferror;
double degplus5 = degreesofturn+rangeoferror;
bool Exit = true;
while(Exit){
 task::sleep(5);
 double heading = fmod((CalulatedHeadingDeg-pastHeading),360);
while(heading < 0){
  heading = heading+360;
}
 
if((degminus5 <=  heading && degplus5 >= heading )){
 Exit = false;
}

}
   LF.stop();
      LR.stop();
      RF.stop();
      RR.stop();
  }
  }



double 

smallturnKp = .1,
smallturnKi = 0.00,
smallturnKd =0.02;


void smallturnToHeadingDeg(double desiredheading,bool Right,bool SmallTurn,bool Smallest,  double motorPower = 50){
directionType leftdirection, rightdirection;
if (Right){leftdirection = forward;rightdirection = reverse;}else{leftdirection = reverse;rightdirection = forward;}
double error, prevError, derivative,totalError,f,d,simulatedCurrent,simulatedDesired;
bool enableTurnPID = true;
double pastMotorPower = 4;
if(SmallTurn == false){
  smallturnKp = .2,
smallturnKi = 0.00,
smallturnKd =0.055;

}
else{
  if(SmallTurn  == true && !Smallest){
    smallturnKp = .15,
smallturnKi = 0.00,
smallturnKd =0.035;  }
else{
smallturnKp = .1,
smallturnKi = 0.00,
smallturnKd =0.02;
}
}
while (enableTurnPID){

 simulatedCurrent = 360-CalulatedHeadingDeg;

  simulatedDesired = 360-desiredheading;


  /* Calulate the Error */
error = simulatedDesired-simulatedCurrent;
//////////////////////////////////////////////////////
  /* Calulate the  Derivative */
  derivative = error-prevError;
  
  /* Calulate The Inegral*/
  if(absd(pastMotorPower) < 3){
  totalError = totalError + error;
  }
  /* Declare Variables*/
  motorPower  = error * smallturnKp + derivative *smallturnKd + totalError * smallturnKi;
  motorPower = keepoutofrange(motorPower, 0.05);
  LF.spin(leftdirection,motorPower,percent);
  LR.spin(leftdirection,motorPower,percent);
  RF.spin(rightdirection,motorPower,percent);
  RR.spin(rightdirection,motorPower,percent);
  prevError = error;pastMotorPower = motorPower;

  
if(Right == true){
  if((desiredheading+1) >=Odometry::CalulatedHeadingDeg && (desiredheading-.5) <=Odometry::CalulatedHeadingDeg ){
    enableTurnPID = false;
  }
}
else{
  if((desiredheading+.5) >=Odometry::CalulatedHeadingDeg && (desiredheading-1) <=Odometry::CalulatedHeadingDeg ){
    enableTurnPID = false;
  }
}
  task::sleep(10);

}
}
/* Turn Pd Settings*/
double 

turnKp = .65,
turnKd =0.12,
turnKi = 0.000;                                                                                                        

void turnToHeadingDeg(double desiredheading,double motorPower = 20,bool setHeading = false, bool Right2 = false){
double error, prevError, derivative , totalError,f,d,simulatedCurrent,simulatedDesired;
bool enableTurnPID = true, Right = true,NearTarget,CurrentHeadingGreater,DesiredHeadingGreater;
directionType leftdirection, rightdirection;
if (desiredheading <0)desiredheading = 360 + desiredheading;

  if(CalulatedHeadingDeg >180){
 simulatedCurrent = (CalulatedHeadingDeg - 180) *-1;
}
else{
  simulatedCurrent = CalulatedHeadingDeg;
}
if(desiredheading > 180){
  simulatedDesired = (desiredheading - 180) *-1;
}
else{
  simulatedDesired = desiredheading;
}
if(simulatedCurrent  < 0&& simulatedDesired < 0){
 if(simulatedCurrent<simulatedDesired){
   Right = false;
 }
 
}

if(simulatedCurrent >=0 && simulatedDesired <0 && CalulatedHeadingDeg + simulatedDesired < 90){

 Right  = false;
}
if(simulatedCurrent >0 && simulatedDesired > 0 ){
  if(simulatedCurrent > simulatedDesired){
    Right = false;
  }
}
if(setHeading){
  Right = Right2;
}
if (Right){leftdirection = forward;rightdirection = reverse;}else{leftdirection = reverse;rightdirection = forward;}
double startingRotation = Inertial1.rotation(deg)*1.01773114*1.01136664*0.988717633;
double heading = CalulatedHeadingDeg;
double turnRotation;
turnRotation =  absd(360-absd(desiredheading-CalulatedHeadingDeg));
if(turnRotation < 45){ 
  enableTurnPID = false;
  smallturnToHeadingDeg(desiredheading,Right,turnRotation<21,turnRotation<10,motorPower);
}
while (enableTurnPID){
 simulatedCurrent = 360-CalulatedHeadingDeg;

  simulatedDesired = 360-desiredheading;

  /* Calulate the Error */
double currentRotation = Inertial1.rotation(deg)*1.01773114*1.01136664*0.988717633-startingRotation + simulatedCurrent ;
error = simulatedDesired-simulatedCurrent;
//////////////////////////////////////////////////////
  /* Calulate the  Derivative */
  derivative = error-prevError;
  
  /* Declare Variables*/
  CurrentHeadingGreater = CalulatedHeadingDeg>desiredheading;
  DesiredHeadingGreater = CalulatedHeadingDeg<desiredheading;
  f = desiredheading-CalulatedHeadingDeg;
  d = CalulatedHeadingDeg - desiredheading;
  
  turnRotation =  absd(360-absd(desiredheading-CalulatedHeadingDeg));
if(turnRotation < 4){
  totalError = totalError +error;
}
  if(CurrentHeadingGreater) if(turnRotation<50) motorPower =  error * turnKp + derivative*turnKd + totalError * turnKi;  
  if(DesiredHeadingGreater) if(turnRotation<50)motorPower = error * turnKp + derivative*turnKd + totalError  * turnKi;
  Brain.Screen.setCursor(7, 1);
  Brain.Screen.clearLine();
  Brain.Screen.print("DH:");
  Brain.Screen.print(desiredheading);
  Brain.Screen.print("MP:");
  Brain.Screen.print(motorPower);
  Brain.Screen.print("TE:");

  Brain.Screen.print(totalError*turnKi);
  Brain.Screen.setCursor(8, 1);
  Brain.Screen.clearLine();
  Brain.Screen.print("E:");
  Brain.Screen.print(error*turnKp);
  Brain.Screen.print("D:");
  Brain.Screen.print(derivative*turnKd);
  motorPower = keepoutofrange(motorPower, 0.05);
  LF.spin(leftdirection,motorPower,percent);
  LR.spin(leftdirection,motorPower,percent);
  RF.spin(rightdirection,motorPower,percent);
  RR.spin(rightdirection,motorPower,percent);
  prevError = error;
  
if(Right == true){
  if((desiredheading+1) >=Odometry::CalulatedHeadingDeg && (desiredheading-.5) <=Odometry::CalulatedHeadingDeg ){
    enableTurnPID = false;
  }
}
else{
  if((desiredheading+.5) >=Odometry::CalulatedHeadingDeg && (desiredheading-1) <=Odometry::CalulatedHeadingDeg ){
    enableTurnPID = false;
  }
}
  task::sleep(10);

}
stopallmotors(hold);

}



void TurntoPoint(double x, double y ,bool add180 = false,bool iscorection = false){
 double desiredheading = Odometry::getDesiredHeadingforRotate(Odometry::xPos,Odometry::Main::yPos,x,y);
 if(desiredheading<0){
   desiredheading = fmod(360+CalulatedHeadingDeg,360);
 }
 if(add180){
   desiredheading = fmod(180+desiredheading, 360);
 }
 double rotation = desiredheading-Odometry::CalulatedHeadingDeg;
rotation = 360- absd(rotation);
if(rotation <=2.5 && !iscorection){
  return;
}
 Brain.Screen.print(desiredheading);
 turnToHeadingDeg(desiredheading);
}
double calculatedistance(double x0,double x1,double y0,double y1){
double d = sqrt(
 ( (x1-x0)*(x1-x0)) + ((y1-y0)*(y1-y0))
);
return d;
}
 double 
 /* Distance Pid Settings */
 kP = 6.5,
 kI = 0.0,
 kD = 0.4,

/* Straight Pid Settings*/
 skD = 0.08,
 skI = 0.0,
 skP = 0.3,

 /* Encoder to In Multipliers */
 EncoderToInL = 0.02408722109,
 EncoderToInR=0.02385972071;

void DriveToPointPid(double desiredX,double desiredY,double startingmotorpower  = 50,double tolerence = 0.2){
TurntoPoint(desiredX,desiredY);
double distance = calculatedistance(xPos,desiredX, yPos,desiredY);
int startingLeftValue = LeftEncoderY.position(deg);
int startingRightValue = RightEncoderY.position(deg);
bool enablePD = true;
double startingY = yPos,startingX = xPos,Lerror= 0,LprevError = 0,Lderivative = 0,Lintegral = 0, Rerror = 0, RprevError = 0,Rderivative = 0,Rintegral = 0, LmotorPower = startingmotorpower,
 RmotorPower = startingmotorpower,
 Rabsoluteposition = 0,
 Labsoluteposition = 0;
/*
if (distance < 0){
  distance =  distance * -1;
}
*/
int i = 0;
while ((( calculatedistance(startingX, xPos ,startingY, yPos)<=  (distance)-0.2))){
if(!(i>=50)){
RmotorPower = startingmotorpower * (i*.02);
}
Rabsoluteposition =(RightEncoderY.position(deg) - startingRightValue) * EncoderToInR;
Rerror = (distance- calculatedistance(startingX, xPos ,startingY, yPos)) ;
Rderivative = Rerror - RprevError;
Rintegral = Rintegral + Rerror;
if((( distance-calculatedistance(startingX, xPos ,startingY, yPos)<=10 ))){
RmotorPower =  (Rerror * kP + Rderivative * kD + Rintegral *kI);// error will be 5 or less so Kp should be between 0 and 16 to keep power less than 80
}

Labsoluteposition = (LeftEncoderY.position(deg) - startingLeftValue)*EncoderToInL;
Lerror = (Rabsoluteposition/ EncoderToInR)-(Labsoluteposition/ EncoderToInL*0.99055514211);
Lderivative = Lerror - LprevError;
Lintegral = Lintegral + Lerror;
LmotorPower = RmotorPower + (Lerror * skP + Lderivative* skD + Lintegral* skI);
/*if (distance < 0) {d
    if (Labsoluteposition < distance) {
        LmotorPower = 0;
    }
}
else {*/


//}
//if (distance < 0) {
//    if (Rabsoluteposition < distance) {
   //     RmotorPower = 0;
  //  }
//}
//else {

// } 
//if (distance < 0) {
  //  if ((Rabsoluteposition < distance) && (Labsoluteposition < distance)) {
//        enablePD = false;
  //  }
//}
//else {
    
//}




LF.spin(forward,LmotorPower,percent);
LR.spin(forward,LmotorPower,percent);
RF.spin(forward,RmotorPower,percent);
RR.spin(forward,RmotorPower,percent);




LprevError = Lerror;RprevError = Rerror;
task::sleep(8);
Rabsoluteposition =(RightEncoderY.position(deg) - startingRightValue) *  EncoderToInR;
Labsoluteposition = (LeftEncoderY.position(deg) - startingLeftValue)* EncoderToInL;
i+=1;
}
stopallmotors(brake);

}


void InverseDriveToPointPid(double desiredX,double desiredY,double startingmotorpower  = 50,double tolerence = 0.2){
TurntoPoint(desiredX,desiredY,true);
double distance = calculatedistance(xPos,desiredX, yPos,desiredY);
int startingLeftValue = LeftEncoderY.position(deg);
int startingRightValue = RightEncoderY.position(deg);
bool enablePD = true;
double startingY = yPos,startingX = xPos,Lerror= 0,LprevError = 0,Lderivative = 0,Lintegral = 0, Rerror = 0, RprevError = 0,Rderivative = 0,Rintegral = 0, LmotorPower = startingmotorpower,
 RmotorPower = startingmotorpower,
 Rabsoluteposition = 0,
 Labsoluteposition = 0;
/*
if (distance < 0){
  distance =  distance * -1;
}
*/
int i = 0;
while ((( calculatedistance(startingX, xPos ,startingY, yPos)<=  (distance)))){
if(!(i>=50)){
RmotorPower = startingmotorpower * (i*.02);
}
Rabsoluteposition =(RightEncoderY.position(deg) - startingRightValue) * EncoderToInR;
Rerror = (distance- calculatedistance(startingX, xPos ,startingY, yPos)) ;
Rderivative = Rerror - RprevError;
Rintegral = Rintegral + Rerror;
if((( distance-calculatedistance(startingX, xPos ,startingY, yPos)<=10 ))){
RmotorPower =  (Rerror * kP + Rderivative * kD + Rintegral *kI);// error will be 5 or less so Kp should be between 0 and 16 to keep power less than 80
}

Labsoluteposition = (LeftEncoderY.position(deg) - startingLeftValue)*EncoderToInL;
Lerror = (Rabsoluteposition/ EncoderToInR)-(Labsoluteposition/ EncoderToInL*0.99055514211);
Lerror = Lerror * -1;
Lderivative = Lerror - LprevError;
Lintegral = Lintegral + Lerror;
LmotorPower = RmotorPower + (Lerror * skP + Lderivative* skD + Lintegral* skI);
/*if (distance < 0) {d
    if (Labsoluteposition < distance) {
        LmotorPower = 0;
    }
}
else {*/


//}
//if (distance < 0) {
//    if (Rabsoluteposition < distance) {
   //     RmotorPower = 0;
  //  }
//}
//else {

// } 
//if (distance < 0) {
  //  if ((Rabsoluteposition < distance) && (Labsoluteposition < distance)) {
//        enablePD = false;
  //  }
//}
//else {
    
//}




LF.spin(reverse,LmotorPower,percent);
LR.spin(reverse,LmotorPower,percent);
RF.spin(reverse,RmotorPower,percent);
RR.spin(reverse,RmotorPower,percent);




LprevError = Lerror;RprevError = Rerror;
task::sleep(8);
Rabsoluteposition =(RightEncoderY.position(deg) - startingRightValue) *  EncoderToInR;
Labsoluteposition = (LeftEncoderY.position(deg) - startingLeftValue)* EncoderToInL;
i+=1;
}
stopallmotors(brake);

}

}
