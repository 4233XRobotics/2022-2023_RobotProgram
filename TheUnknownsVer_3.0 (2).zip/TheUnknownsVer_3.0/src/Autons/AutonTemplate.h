#include "AutonFunctions.h"
#include "robot-config.h"
#include <string.h>
using namespace Auton::AutonFunctions;
using namespace ButtonControls;
namespace Auton{
  namespace Autons{
    
    void AutonName(){
    
    }
  }
}