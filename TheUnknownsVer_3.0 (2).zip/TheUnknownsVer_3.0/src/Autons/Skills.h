#include "WinpointRight.h"
#include "robot-config.h"
using namespace Auton::AutonFunctions;
using namespace ButtonControls;
namespace Auton {
    namespace Autons {
       void TimerHeheheh() {
            waitUntil(Brain.Timer.time(sec) >= 60);
            old_Turn(true, 440);
        }
       void FirstPartofSkills(){
LF.spin(reverse, 30, percent);
         
            ColorSpinnerFunctions::SpinUntilRed(false);
            stopallmotors();
            old_Drive(3, 150);
            old_Turn(false, 310,50);
            IntakeFunctions::StartIntake();
            old_Drive(8, 100,fwd,hold);

            old_Turn(false, 184,40);
            
                       thread d(IntakeFunctions::StartIntake);
            LF.spin(reverse,30,percent);
            LR.stop(coast);
            RF.spin(reverse, 30, percent);
         RR.stop(coast);
             task::sleep(300);
            ColorSpinnerFunctions::SpinUntilRed(false,true);
            stopallmotors();
                  /* Time to turn and shoot at the goal */
            old_Drive(3,150);
            old_Turn(false, 300,50);
                   ShootingPower = 73;
                thread e(Shoot);
            old_Drive(44, 150);

            old_Turn(true,6.5,40);
            Shoot();
            task::sleep(350);
                Shoot();
            task::sleep(450);
               Shoot();
            task::sleep(350);
            /* Get line of 3 */
            old_Turn(false,359,25);
            
            old_Drive(29.5, 150,reverse);
                        thread jw(IntakeFunctions::StartIntake);
            old_Turn(true, 28.5,40); 
            task::sleep(500);
            old_Drive(16, 100); 
            task::sleep(250);
                old_Drive(16, 100); 
                         task::sleep(250);
                    old_Drive(19, 100); 
                             
            ShootingPower = 75;
            FlywheelMainMotor.spin(forward, ((12.5 * ShootingPower) * 0.01), voltageUnits::volt);
            old_Turn(false,277.8,50);
            thread e7(IntakeFunctions::addpower);
            
            task::sleep(500);
            Shoot();
            task::sleep(375);
              Shoot();
            task::sleep(505);
              Shoot();
              thread jw2(IntakeFunctions::StartIntake);
            task::sleep(375);
       }
        void Skills() {
            //FirstPartofSkills();
            Shoot();
            /* Get three disks in the middle */
          IntakeFunctions::StartIntake();
            old_Turn(true,108,50);
            old_Drive(6, 150);
            old_Turn(true, 86,40,1.5);
             
            old_Drive(22, 150);
                 ShootingPower= 73;
               FlywheelMainMotor.spin(forward, ((12.5 * ShootingPower) * 0.01), voltageUnits::volt);
            old_Turn(false,320,50);
            old_Drive(11, 150);
            old_Turn(false, 350,50);
            IntakeFunctions::addpower();
            task::sleep(350);
               Shoot();
            task::sleep(650);
                Shoot();
            task::sleep(350);
               Shoot();
            task::sleep(350);
                 thread e(IntakeFunctions::StartIntake);
            old_Turn(false,293,50);
            task::sleep(750);
            thread e2(IntakeFunctions::StartIntake);
            old_Drive(60,150);
            old_Turn(true, 127,50);
            addpower();
            old_Drive(15, 150);
     
                 task::sleep(350);
               Shoot();
            task::sleep(650);
                Shoot();
            task::sleep(350);
               Shoot();
            task::sleep(350);
            old_Turn(false, 358,20);
        }
         void Archive(){
          /* Milford Skills*/
                  LF.spin(reverse, 30, percent);
         
            ColorSpinnerFunctions::SpinUntilRed(false);
            stopallmotors();
            old_Drive(6, 150);
            ShootingPower = 83;
            thread e(Shoot);
                        old_Turn(true, 62, 50);
            old_Drive(15, 150);
           
            task::sleep(500);
            Shoot();
            task::sleep(1000);
            Shoot();
            task::sleep(1000);

            STOPShoot();
            old_Turn(false, 272, 50);

            ShootingPower = 83;
            SpinningPower = -85;
            IntakeFunctions::StartIntake();
            old_Drive(8, 150);
                    SpinningPower = 85;
                  Intake.spin(reverse,SpinningPower,percent);
             old_Drive(15, 20);
            Shoot();
            old_Turn(true, 111, 50);
            IntakeFunctions::StartIntake();
            task::sleep(500);
            SpinningPower = -75;
            IntakeFunctions::StartIntake();
            ShootingPower = 92;
            
                        Shoot();
            task::sleep(1000);
            Shoot();
            task::sleep(1000);
            Shoot();
            task::sleep(1000);
            thread f42342342e(STOPShoot);
            thread e23(IntakeFunctions::StartIntake);
             old_Drive(4, 100);
            task::sleep(1000);
             old_Turn(false, 292, 50);
            SpinningPower = 75;
            IntakeFunctions::StartIntake();
             old_Drive(51, 130);
            ShootingPower = 82 ;
            Shoot();
            IntakeFunctions::StartIntake();
            SpinningPower = -75;
            IntakeFunctions::StartIntake();
             old_Turn(true, 111, 50);

            Shoot();
            task::sleep(1000);
            Shoot();
            task::sleep(1000);
                Shoot();
            task::sleep(1000);
            STOPShoot();
            StartIntake();
             old_Turn(true, 3, 50);
             old_Drive(20, 150, reverse);
             old_Turn(true,38);
            LF.spin(reverse, 30, percent);
            LR.spin(reverse, 30, percent);
            RF.spin(reverse, 30, percent);
            RR.spin(reverse, 30, percent);
             task::sleep(300);
            ColorSpinnerFunctions::SpinUntilRed(true);
            stopallmotors();
             old_Drive(11, 150);
             old_Turn(false, 275,50);
            LF.spin(reverse, 30, percent);
            LR.spin(reverse, 30, percent);
            RF.spin(reverse, 30, percent);
            RR.spin(reverse, 30, percent);
             task::sleep(300);
            ColorSpinnerFunctions::SpinUntilRed(true);
            
             old_Drive(14,150);
              old_Turn(true,45,50);
             Pnematics.set(true);
             task::sleep(1000);
                Pnematics.set(false);
                 old_Drive(1,150,reverse);

            stopallmotors(coast);
        }
    }
}