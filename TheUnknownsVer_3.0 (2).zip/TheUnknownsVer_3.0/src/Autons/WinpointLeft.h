#include "LeftSpin.h"
#include "robot-config.h"
using namespace Auton::AutonFunctions;
using namespace ButtonControls;
namespace Auton{

  namespace Autons{
  
    void WinPointLeft(){
   
  thread (StopAt15);
    old_Drive(2.25,75);
    old_Turn(false,359,18,0.5);
    ShootingPower = 100;
    Shoot();
    wait(2,sec);
    Shoot();
    wait(750,msec);
    ShootingPower = 95;
    FlywheelMainMotor.spin(forward, ((12.5 * ShootingPower) * 0.01), voltageUnits::volt);
    Shoot();
    wait(300,msec);
      old_Turn(true,1.5,18);
    STOPShoot();
        LF.spin(reverse,40,percent);
      LR.stop(coast);
       RR.stop(coast);
      RF.spin(reverse,40,percent);
     ColorSpinnerMainFunction();
     stopallmotors();
     old_Drive(3, 150);
     task::sleep(200);
     SpinningPower = 95;
     thread e(StartIntake);
     old_Turn(true,25,50);
     task::sleep(200);
     old_Drive(20, 150);
     task::sleep(200);
     ShootingPower = 95;
       Shoot();
     old_Drive(11, 40);
    
       old_Turn(false, 311,50);

task::sleep(200);
     thread f(IntakeFunctions::addpower);
    Shoot();
    wait(750,msec);
    Shoot();
    wait(750,msec);
    Shoot();
    wait(750,msec);
    STOPShoot();
    SpinningPower = 85;
    }
  } 
}