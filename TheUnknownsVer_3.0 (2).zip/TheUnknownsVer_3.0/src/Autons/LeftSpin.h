#include "AutonFunctions.h"
#include "robot-config.h" // a
using namespace Auton::AutonFunctions;
using namespace ButtonControls::ColorSpinnerFunctions;
using namespace ButtonControls::ShooterFunctions;
using namespace ButtonControls::IntakeFunctions;
using namespace ButtonControls;
namespace Auton{
  namespace Autons{
    void LeftSpin(){
      
      LF.spin(reverse,40,percent);
      LR.spin(reverse,40,percent);
      RF.spin(reverse,40,percent);
      RR.spin(reverse,40,percent);

if(ButtonControls::IsBlue == true){
  SpinUntilBlue();
}
else{
  SpinUntilRed();
}
     ButtonControls::stopallmotors();

    }
  }
}