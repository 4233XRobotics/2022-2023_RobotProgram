// This is a namespace file that compiles all of these files into a namespace named "ButtonControls"
#include "../src/ButtonControls/ColorSpinnerFunctions.h"
#include "../src/ButtonControls/ShooterFunctions.h"
#include "../src/ButtonControls/IntakeFunctions.h"
#include "../src/ButtonControls/EndGameFunctions.h"
namespace ButtonControls{
  void stopallmotors(brakeType type = coast){
    LF.stop(type);
    LR.stop(type);
    RF.stop(type);
    RR.stop(type);
  }
}
